"""
Service account credentials for LucidLink authentication.
"""

from ._redaction import VALID_TOKEN_PREFIXES, redact_service_account_token


class ServiceAccountCredentials:
    """
    Service account authentication credentials.

    Service account tokens are generated from WebClient or BackOffice and provide
    programmatic access to LucidLink workspaces and filespaces.

    Token format: sa_live:your_key

    Example:
        .. code-block:: python

            token = "sa_live:your_key"
            credentials = ServiceAccountCredentials(token)
            workspace = daemon.authenticate(credentials)
    """

    def __init__(self, token: str):
        """
        Initialize service account credentials.

        Args:
            token: Service account token (e.g. sa_live:your_key)

        Raises:
            ValueError: If token format is invalid
        """
        if not token:
            raise ValueError("Service account token cannot be empty")

        if not any(token.startswith(f"{p}:") for p in VALID_TOKEN_PREFIXES):
            raise ValueError("Invalid service account token format.")

        # Basic validation: must have at least 2 colons
        parts = token.split(":")
        if len(parts) < 3:
            raise ValueError("Invalid service account token format.")

        self.token = token

    def __repr__(self) -> str:
        # Don't expose the full token in repr for security
        return f"ServiceAccountCredentials(token='{redact_service_account_token(self.token)}')"
