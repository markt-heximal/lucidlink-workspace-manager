"""
**LucidLink Python Library**

Python bindings for LucidLink Core C++ daemon library.
Provides programmatic access to LucidLink filespaces from Python.

See the :doc:`quickstart` for usage examples.
"""

# Import main classes
from .credentials import ServiceAccountCredentials
from .daemon import Daemon
from .workspace import Workspace
from .filespace import Filespace
from .filesystem import Filesystem, FileHandle

# Import streaming classes
from .stream import LucidFileStream, open_buffered, open_text

# Import storage configuration
from .storage import StorageConfig, StorageMode

# Import Connect (external files) classes
from .connect import ConnectManager
from .connect_models import (
    S3DataStoreConfig,
    DataStoreInfo,
    LinkedFilesResult,
    DataStoreKind,
    DataStoreRekeyState,
    S3Credentials,
    DataStoreCredentials,
)

# Import fsspec integration (optional - requires fsspec package)
try:
    from .fsspec import LucidLinkFileSystem
    _FSSPEC_AVAILABLE = True
except ImportError:
    _FSSPEC_AVAILABLE = False
    LucidLinkFileSystem = None

# Import custom exceptions
from .exceptions import (
    LucidLinkError,
    DaemonError,
    FilespaceError,
    AuthenticationError,
    ConfigurationError,
)

# Import type definitions
from .filespace_models import SyncMode, FilespaceInfo, DaemonStatus
from .filesystem_models import DirEntry, FilespaceSize, FilespaceStatistics

# Import typing for factory function
from typing import Dict, Optional, Union
from pathlib import Path

__version__ = "0.10.0"

__all__ = [name for name in dir() if not name.startswith("_")]


def create_daemon(
    config: Optional[Dict[str, str]] = None,
    sandboxed: bool = True,
    persist_files: bool = False,
    root_path: Optional[Union[str, Path]] = None,
) -> Daemon:
    """
    Create a ``Daemon`` with simplified storage configuration.

    This is a convenience factory that makes it easier to configure daemon
    storage without needing to manually create ``StorageConfig`` objects.

    Args:
        config: Additional daemon configuration options (cache size, etc.)
        sandboxed: If ``True`` (default), use temp directory that's always cleaned up.
                  If ``False``, use ``.lucid`` subfolder in current directory.
        persist_files: If ``False`` (default), clean up files when daemon stops.
                      Only applies when ``sandboxed=False``.
                      Sandboxed mode always cleans up.
        root_path: Override root path for files (only when ``sandboxed=False``).
                  If ``None``, uses current working directory.

    Returns:
        ``Daemon`` instance with specified storage configuration

    Example:
        .. code-block:: python

            # Sandboxed (default) - files in temp, always cleaned up
            daemon = lucidlink.create_daemon()

            # Physical with cleanup - files in .lucid/, cleaned up on exit
            daemon = lucidlink.create_daemon(sandboxed=False)

            # Physical with persistence - files in .lucid/, kept after exit
            daemon = lucidlink.create_daemon(sandboxed=False, persist_files=True)

            # Custom root path
            daemon = lucidlink.create_daemon(
                sandboxed=False,
                root_path="D:/lucid_data",
            )

            # With custom config
            daemon = lucidlink.create_daemon(
                config={"fs.cache.size": "2048"},
                sandboxed=False,
                persist_files=True,
            )
    """
    if sandboxed:
        storage = StorageConfig(mode=StorageMode.SANDBOXED)
    else:
        storage = StorageConfig(
            mode=StorageMode.PHYSICAL,
            persist_on_exit=persist_files,
            root_path=Path(root_path) if root_path else None,
        )
    return Daemon(config=config, storage=storage)
