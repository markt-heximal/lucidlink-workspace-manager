"""
FileSystem class and its C ABI bindings.

Covers: file operations, directory ops, symlinks, byte-range locking,
metadata/entry accessors, size/statistics, and SyncAll. Mirrors the C side
at ``Sdk/Api/lucid_api_filesystem.cpp``.
"""

import ctypes
from ctypes import POINTER, c_char_p, c_int, c_int64, c_ssize_t, c_uint32, c_uint64, c_void_p

from ._errors import _check
from ._helpers import _NativeHandleOwner, _encode_path, _free
from ._loader import _bind, _bind_pydll

# FileSystem bindings use a per-method GIL policy:
#
#   * _bind        (CDLL, GIL released) — blocking I/O methods (read,
#     write, open, close, mkdir, rmdir, sync_all, byte-range locks, …).
#     Other Python threads can progress while liblucid waits on disk or
#     network.
#
#   * _bind_pydll  (PyDLL, GIL held)    — fast metadata accessors
#     (file_exists, dir_exists, read_symlink, get_size, get_statistics,
#     get_id, get_name) and the iterator-stepping bindings that build a
#     Python list/dict (read_dir, get_entry). Releasing the GIL on
#     these would add lock churn without giving any other thread
#     useful time, since the calls return immediately.

# ── Filespace identity (used by FileSystem.get_id / get_name) ─────────
_filespace_id = _bind_pydll("lucid_filespace_id", c_char_p, [c_void_p])
_filespace_name = _bind_pydll("lucid_filespace_name", c_char_p, [c_void_p])

# ── File operations ───────────────────────────────────────────────────
_open = _bind("lucid_open", c_uint64, [c_void_p, c_char_p, c_char_p, c_char_p])
_create = _bind("lucid_create", c_uint64, [c_void_p, c_char_p])
_read = _bind("lucid_read", c_int64, [c_void_p, c_uint64, c_void_p, c_int64, c_uint64])
_write = _bind("lucid_write", c_int64, [c_void_p, c_uint64, c_void_p, c_int64, c_uint64])
_close = _bind("lucid_close", c_int, [c_void_p, c_uint64])
_delete_file = _bind("lucid_delete_file", c_int, [c_void_p, c_char_p])
_move = _bind("lucid_move", c_int, [c_void_p, c_char_p, c_char_p])
_file_exists = _bind_pydll("lucid_file_exists", c_int, [c_void_p, c_char_p])
_truncate = _bind("lucid_truncate", c_int, [c_void_p, c_char_p, c_uint64])
_truncate_by_handle = _bind("lucid_truncate_by_handle", c_int, [c_void_p, c_uint64, c_uint64])

# ── Byte-range locking ────────────────────────────────────────────────
_lock_byte_range = _bind(
    "lucid_lock_byte_range", c_int,
    [c_void_p, c_uint64, c_uint64, c_uint64, c_char_p, c_int],
)
_unlock_byte_range = _bind("lucid_unlock_byte_range", c_int, [c_void_p, c_uint64, c_uint64, c_uint64])
_unlock_all = _bind("lucid_unlock_all_byte_ranges", c_int, [c_void_p, c_uint64])

# ── Convenience: whole-file read/write ────────────────────────────────
_read_file = _bind("lucid_read_file", c_int, [c_void_p, c_char_p, POINTER(c_void_p), POINTER(c_int64)])
_write_file = _bind("lucid_write_file", c_int, [c_void_p, c_char_p, c_void_p, c_int64])

# ── Directory operations ──────────────────────────────────────────────
_mkdir = _bind("lucid_mkdir", c_int, [c_void_p, c_char_p])
_rmdir = _bind("lucid_rmdir", c_int, [c_void_p, c_char_p, c_int])
_dir_exists = _bind_pydll("lucid_dir_exists", c_int, [c_void_p, c_char_p])

# ── Symbolic links ────────────────────────────────────────────────────
_create_symlink = _bind("lucid_create_symlink", c_int, [c_void_p, c_char_p, c_char_p])
_read_symlink = _bind_pydll("lucid_read_symlink", c_void_p, [c_void_p, c_char_p])

# ── Directory listing ─────────────────────────────────────────────────
_readdir = _bind_pydll("lucid_readdir", c_void_p, [c_void_p, c_char_p])
_dir_next = _bind_pydll("lucid_dir_next", c_int, [c_void_p])
_dir_entry_name = _bind_pydll("lucid_dir_entry_name", c_char_p, [c_void_p])
_dir_entry_size = _bind_pydll("lucid_dir_entry_size", c_int64, [c_void_p])
_dir_entry_is_dir = _bind_pydll("lucid_dir_entry_is_dir", c_int, [c_void_p])
_dir_entry_is_link = _bind_pydll("lucid_dir_entry_is_link", c_int, [c_void_p])
_dir_entry_mtime = _bind_pydll("lucid_dir_entry_mtime", c_int64, [c_void_p])
_dir_iter_destroy = _bind_pydll("lucid_dir_iter_destroy", None, [c_void_p])

# ── Entry metadata (opaque handle + accessors) ────────────────────────
_get_entry = _bind_pydll("lucid_get_entry", c_void_p, [c_void_p, c_char_p])
_entry_name = _bind_pydll("lucid_entry_name", c_char_p, [c_void_p])
_entry_file_id = _bind_pydll("lucid_entry_file_id", c_char_p, [c_void_p])
_entry_file_id_ext = _bind_pydll("lucid_entry_file_id_ext", c_uint64, [c_void_p])
_entry_size = _bind_pydll("lucid_entry_size", c_int64, [c_void_p])
_entry_is_file = _bind_pydll("lucid_entry_is_file", c_int, [c_void_p])
_entry_is_directory = _bind_pydll("lucid_entry_is_directory", c_int, [c_void_p])
_entry_is_link = _bind_pydll("lucid_entry_is_link", c_int, [c_void_p])
_entry_is_root = _bind_pydll("lucid_entry_is_root", c_int, [c_void_p])
_entry_is_share = _bind_pydll("lucid_entry_is_share", c_int, [c_void_p])
_entry_creation_time = _bind_pydll("lucid_entry_creation_time", c_int64, [c_void_p])
_entry_update_time = _bind_pydll("lucid_entry_update_time", c_int64, [c_void_p])
_entry_snapshot_id = _bind_pydll("lucid_entry_snapshot_id", c_uint32, [c_void_p])
_entry_unix_uid = _bind_pydll("lucid_entry_unix_uid", c_uint32, [c_void_p])
_entry_unix_gid = _bind_pydll("lucid_entry_unix_gid", c_uint32, [c_void_p])
_entry_unix_mode = _bind_pydll("lucid_entry_unix_mode", c_uint32, [c_void_p])
_entry_windows_attributes = _bind_pydll("lucid_entry_windows_attributes", c_uint32, [c_void_p])
_entry_destroy = _bind_pydll("lucid_entry_destroy", None, [c_void_p])

_get_size_by_handle = _bind_pydll("lucid_get_size_by_handle", c_int, [c_void_p, c_uint64, POINTER(c_int64)])


class _LucidSizeInfo(ctypes.Structure):
    _fields_ = [
        ("entries_size", c_int64),
        ("data_size", c_int64),
        ("storage_size", c_int64),
        ("external_files_size", c_int64),
        ("external_files_count", c_uint64),
    ]


_get_size = _bind_pydll("lucid_get_size", c_int, [c_void_p, POINTER(_LucidSizeInfo)])


class _LucidStats(ctypes.Structure):
    _fields_ = [
        ("file_count", c_uint64),
        ("dir_count", c_uint64),
        ("symlink_count", c_uint64),
        ("size", _LucidSizeInfo),
    ]


_get_statistics = _bind_pydll("lucid_get_statistics", c_int, [c_void_p, POINTER(_LucidStats)])
_sync_all = _bind("lucid_sync_all", c_int, [c_void_p])

# ── CPython API bindings ──────────────────────────────────────────────
# FileSystem.read() allocates an uninitialized bytes via
# PyBytes_FromStringAndSize(NULL, n) so the SDK writes straight into its
# final storage — zero memcpy on a full-buffer read. Partial reads pay one
# memcpy: allocate a right-sized bytes with the copying form (src != NULL)
# and drop the oversized original via normal refcounting.
_PyBytes_FromStringAndSize = ctypes.pythonapi.PyBytes_FromStringAndSize
# c_void_p (not c_char_p) so None passes through as NULL for the
# uninitialized-allocation form.
_PyBytes_FromStringAndSize.argtypes = [c_void_p, c_ssize_t]
_PyBytes_FromStringAndSize.restype = ctypes.py_object


def _entry_to_dict(entry):
    name_ptr = _entry_name(entry)
    file_id_ptr = _entry_file_id(entry)
    is_file = bool(_entry_is_file(entry))
    is_dir = bool(_entry_is_directory(entry))
    is_link = bool(_entry_is_link(entry))
    return {
        "name": name_ptr.decode() if name_ptr else "",
        "file_id": file_id_ptr.decode() if file_id_ptr else "",
        "file_id_external": _entry_file_id_ext(entry),
        "size": _entry_size(entry),
        "is_file": is_file,
        "is_dir": is_dir,
        "is_link": is_link,
        "is_root": bool(_entry_is_root(entry)),
        "is_share": bool(_entry_is_share(entry)),
        "creation_time": _entry_creation_time(entry),
        "update_time": _entry_update_time(entry),
        "snapshot_id": _entry_snapshot_id(entry),
        "unix_uid": _entry_unix_uid(entry),
        "unix_gid": _entry_unix_gid(entry),
        "unix_mode": _entry_unix_mode(entry),
        "windows_attributes": _entry_windows_attributes(entry),
        "type": (
            "file" if is_file
            else ("dir" if is_dir
                  else ("link" if is_link else "unknown"))
        ),
    }


class FileSystem(_NativeHandleOwner):
    """FileSystem operations on a linked filespace."""

    def __init__(self, fs_handle):
        self._h = fs_handle

    def read_dir(self, path):
        it = _check(_readdir(self._h, _encode_path(path)), None)
        try:
            entries = []
            while _dir_next(it) == 1:
                is_dir = bool(_dir_entry_is_dir(it))
                is_link = bool(_dir_entry_is_link(it))
                is_file = (not is_dir) and (not is_link)
                if is_file:
                    type_str = "file"
                elif is_dir:
                    type_str = "dir"
                elif is_link:
                    type_str = "link"
                else:
                    type_str = "unknown"
                # file_id / file_id_external / creation_time aren't exposed by the
                # directory iterator; consumers needing them call get_entry().
                entries.append({
                    "name": _dir_entry_name(it).decode(),
                    "size": _dir_entry_size(it),
                    "type": type_str,
                    "is_file": is_file,
                    "is_dir": is_dir,
                    "is_link": is_link,
                    "file_id": "",
                    "file_id_external": 0,
                    "creation_time": 0,
                    "update_time": _dir_entry_mtime(it),
                })
            return entries
        finally:
            _dir_iter_destroy(it)

    def create_dir(self, path):
        _check(_mkdir(self._h, _encode_path(path)), -1)

    def delete_dir(self, path, recursive=False):
        _check(_rmdir(self._h, _encode_path(path), 1 if recursive else 0), -1)

    def dir_exists(self, path):
        return _dir_exists(self._h, _encode_path(path)) == 1

    def create_symlink(self, target_path, link_path):
        _check(_create_symlink(self._h, _encode_path(target_path), _encode_path(link_path)), -1)

    def read_symlink(self, link_path):
        raw = _check(_read_symlink(self._h, _encode_path(link_path)), None)
        try:
            return ctypes.cast(raw, c_char_p).value.decode()
        finally:
            _free(raw)

    def open(self, path, mode, lock_type=""):
        return _check(
            _open(self._h, _encode_path(path), mode.encode(), (lock_type or "").encode()),
            0,
        )

    def create(self, path):
        return _check(_create(self._h, _encode_path(path)), 0)

    def read(self, handle_id, size=-1, offset=0):
        # size == 0 means "return empty"; size < 0 means "read everything we can".
        if size == 0:
            return b""
        file_size = self.get_size_by_handle(handle_id)
        available = max(0, file_size - offset)
        buf_size = size if size > 0 else 65536
        if buf_size > available:
            buf_size = available
        # Allocate uninitialized bytes; SDK writes into its storage directly.
        # ctypes converts `bytes` to c_void_p as a pointer to the internal
        # buffer (same path as `_write` below) — no PyBytes_AsString needed.
        buf = _PyBytes_FromStringAndSize(None, buf_size)
        n = _check(_read(self._h, handle_id, buf, buf_size, offset), -1)
        if n == buf_size:
            return buf
        if n == 0:
            return b""
        # Partial read: copy n bytes into a right-sized bytes; the oversized
        # `result` is dropped via refcounting on return.
        return buf[:n]

    def write(self, handle_id, data, offset=0):
        return _check(_write(self._h, handle_id, data, len(data), offset), -1)

    def close(self, handle_id):
        _check(_close(self._h, handle_id), -1)

    def delete(self, path):
        _check(_delete_file(self._h, _encode_path(path)), -1)

    def move(self, src_path, dst_path):
        _check(_move(self._h, _encode_path(src_path), _encode_path(dst_path)), -1)

    def file_exists(self, path):
        return _file_exists(self._h, _encode_path(path)) == 1

    def get_entry(self, path):
        entry = _check(_get_entry(self._h, _encode_path(path)), None)
        try:
            return _entry_to_dict(entry)
        finally:
            _entry_destroy(entry)

    def get_size_by_handle(self, handle_id):
        out = c_int64(0)
        _check(_get_size_by_handle(self._h, handle_id, ctypes.byref(out)), -1)
        return out.value

    def get_size(self):
        info = _LucidSizeInfo()
        _check(_get_size(self._h, ctypes.byref(info)), -1)
        return {
            "entries": info.entries_size,
            "data": info.data_size,
            "storage": info.storage_size,
            "external_files_size": info.external_files_size,
            "external_files_count": info.external_files_count,
        }

    def get_statistics(self):
        stats = _LucidStats()
        _check(_get_statistics(self._h, ctypes.byref(stats)), -1)
        return {
            "entries": {
                "files": stats.file_count,
                "dirs": stats.dir_count,
                "symlinks": stats.symlink_count,
            },
            "size": {
                "entries": stats.size.entries_size,
                "data": stats.size.data_size,
                "storage": stats.size.storage_size,
                "external_files_size": stats.size.external_files_size,
                "external_files_count": stats.size.external_files_count,
            },
        }

    def sync_all(self):
        _check(_sync_all(self._h), -1)

    def set_end_of_file(self, path, size):
        _check(_truncate(self._h, _encode_path(path), size), -1)

    def set_end_of_file_by_handle(self, handle_id, size):
        _check(_truncate_by_handle(self._h, handle_id, size), -1)

    def lock_byte_range(self, handle_id, offset, length, lock_type, blocking=True):
        result = _check(
            _lock_byte_range(
                self._h, handle_id, offset, length,
                lock_type.encode(), 1 if blocking else 0,
            ),
            -1,
        )
        return bool(result)

    def unlock_byte_range(self, handle_id, offset, length):
        _check(_unlock_byte_range(self._h, handle_id, offset, length), -1)

    def unlock_all_byte_ranges(self, handle_id):
        _check(_unlock_all(self._h, handle_id), -1)

    def get_id(self):
        raw = _filespace_id(self._h)
        return raw.decode() if raw else ""

    def get_name(self):
        raw = _filespace_name(self._h)
        return raw.decode() if raw else ""
