"""
liblucid library lookup and dual CDLL/PyDLL load.

Two ctypes handles are exposed over the same liblucid binary:

* ``_lib`` (CDLL) — releases the GIL across each native call. Used for
  high-throughput I/O bindings (``_filesystem``, ``_connect``) so other
  Python threads can run while liblucid waits on disk/network.
* ``_lib_pydll`` (PyDLL) — holds the GIL across each native call. Used
  for ``Daemon`` lifecycle bindings (``_daemon``) so two threads cannot
  race the Python-side state mutations on the ``Daemon`` instance.

Other ``_*.py`` modules import ``_bind`` (CDLL) or ``_bind_pydll``
(PyDLL) per binding, depending on the GIL policy each call needs.
"""

import atexit
import ctypes
import importlib.resources
import os
import sys


def _find_lib():
    if sys.platform == "darwin":
        libname = "liblucid.dylib"
    elif sys.platform.startswith("win"):
        libname = "lucid.dll"
    else:
        libname = "liblucid.so"
    ref = importlib.resources.files("lucidlink") / libname
    ctx = importlib.resources.as_file(ref)  # extracts from zip if needed
    path = ctx.__enter__()
    atexit.register(ctx.__exit__, None, None, None)
    if not os.path.exists(path):
        raise RuntimeError(
            f"Could not locate {libname} inside the lucidlink package; "
            "reinstall the package (pip install or pip install -e)."
        )
    return str(path)


# Resolve the library path once; the OS reuses the underlying dlopen
# mapping when we open it via both CDLL and PyDLL, but each Python wrapper
# tracks its own per-function argtypes/restype.
_lib_path = _find_lib()
_lib = ctypes.CDLL(_lib_path)
_lib_pydll = ctypes.PyDLL(_lib_path)


def _bind(name, restype, argtypes):
    """Bind a C symbol via CDLL: GIL is released across the call."""
    fn = getattr(_lib, name)
    fn.restype = restype
    fn.argtypes = argtypes
    return fn


def _bind_pydll(name, restype, argtypes):
    """Bind a C symbol via PyDLL: GIL is held across the call.

    Use for Daemon lifecycle methods that mutate Python-side state on the
    ``Daemon`` instance (``_workspace_handle``, ``_fs_handle``, ``_connect``).
    Holding the GIL across the native call prevents another Python thread
    from entering a sibling Daemon method while the first is mid-flight.
    """
    fn = getattr(_lib_pydll, name)
    fn.restype = restype
    fn.argtypes = argtypes
    return fn
