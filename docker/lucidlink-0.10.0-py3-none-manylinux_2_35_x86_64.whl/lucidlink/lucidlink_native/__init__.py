"""
ctypes shim for the LucidLink C ABI (``liblucid``).

The module exposes ``Daemon``, ``FileSystem``, and ``Connect`` classes that
the ergonomic Python SDK at ``lucidlink/src/lucidlink/*.py`` consumes via
``from . import lucidlink_native``.

Library resolution: the shim looks for ``liblucid.{so,dylib,dll}`` via
``importlib.resources.files("lucidlink")``, which works for both regular
pip installs and editable installs (``pip install -e .``).
``importlib.resources.as_file()`` transparently extracts to a temporary file
when the wheel is loaded from a zip archive (PyInstaller bundles, zipapp
distributions).

Internal layout:
  _loader.py      — library lookup and CDLL load
  _errors.py      — exception mapping and the _check error gate
  _helpers.py     — _encode_path and the lucid_free binding
  _filesystem.py  — FileSystem class + its bindings
  _connect.py     — Connect class + its bindings
  _daemon.py      — Daemon class + its bindings
"""

# Class re-exports — these are the public surface tests and the higher-level
# wrappers (lucidlink/daemon.py etc.) consume as `lucidlink_native.Daemon`.
# Each of these transitively imports _loader (for _bind) and _errors (for
# _check), so the CDLL load and error-accessor bindings run on first import.
from ._connect import Connect
from ._daemon import Daemon
from ._filesystem import FileSystem

__all__ = ["Daemon", "FileSystem", "Connect"]
