"""
Connect class and its C ABI bindings.

Covers: Connect handle acquisition (_get_connect bridges filespace → Connect),
data-store management, data-store listing iterator, external-file linking
(S3 and HTTP), and external-file listing iterator. Mirrors the C side at
``Sdk/Api/lucid_api_connect.cpp``.
"""

from ctypes import c_char_p, c_int, c_int64, c_uint32, c_uint64, c_void_p

from ._errors import _check
from ._helpers import _NativeHandleOwner, _encode_path
from ._loader import _bind, _bind_pydll

# Connect bindings follow the same per-binding GIL split as the
# filesystem module:
#
#   * _bind        (CDLL, GIL released) — operations that go into Core
#     and may block on I/O (data-store CRUD, link/unlink, the initial
#     list/get call that fetches the iterator).
#   * _bind_pydll  (PyDLL, GIL held)    — iterator-stepping accessors
#     (_ds_iter_*, _ef_iter_*) and _get_connect.
#
# Iterator stepping is held because the underlying iterator is already
# materialised in Core after the initial list call; each step is a
# cheap field accessor on a pre-fetched record. Releasing the GIL per
# step would add lock churn (~ten calls per result row) without giving
# any other thread useful time.
#
# _get_connect is held because Daemon.get_connect caches the resulting
# Connect on the Daemon instance — holding the GIL across this call
# serializes that mutation with the rest of Daemon's lifecycle methods.

# ── Connect: lifecycle ────────────────────────────────────────────────
_get_connect = _bind_pydll("lucid_get_connect", c_void_p, [c_void_p])
_connect_destroy = _bind("lucid_connect_destroy", None, [c_void_p])
_connect_are_data_stores_available = _bind(
    "lucid_connect_are_data_stores_available", c_int, [c_void_p]
)

# ── Connect: data store management ────────────────────────────────────
_connect_add_ds = _bind(
    "lucid_connect_add_data_store", c_int,
    [c_void_p, c_char_p, c_char_p, c_char_p, c_char_p, c_char_p, c_char_p, c_uint32, c_int],
)
_connect_remove_ds = _bind("lucid_connect_remove_data_store", c_int, [c_void_p, c_char_p])
_connect_rekey_ds = _bind(
    "lucid_connect_rekey_data_store", c_int, [c_void_p, c_char_p, c_char_p, c_char_p]
)

# ── Connect: data store listing ───────────────────────────────────────
_connect_list_ds = _bind("lucid_connect_list_data_stores", c_void_p, [c_void_p])
_connect_get_ds = _bind("lucid_connect_get_data_store", c_void_p, [c_void_p, c_char_p])
_ds_iter_next = _bind_pydll("lucid_ds_iter_next", c_int, [c_void_p])
_ds_iter_name = _bind_pydll("lucid_ds_iter_name", c_char_p, [c_void_p])
_ds_iter_access_key = _bind_pydll("lucid_ds_iter_access_key", c_char_p, [c_void_p])
_ds_iter_secret_key = _bind_pydll("lucid_ds_iter_secret_key", c_char_p, [c_void_p])
_ds_iter_bucket = _bind_pydll("lucid_ds_iter_bucket", c_char_p, [c_void_p])
_ds_iter_region = _bind_pydll("lucid_ds_iter_region", c_char_p, [c_void_p])
_ds_iter_endpoint = _bind_pydll("lucid_ds_iter_endpoint", c_char_p, [c_void_p])
_ds_iter_url_expiration = _bind_pydll("lucid_ds_iter_url_expiration", c_uint32, [c_void_p])
_ds_iter_use_virtual_addressing = _bind_pydll("lucid_ds_iter_use_virtual_addressing", c_int, [c_void_p])
_ds_iter_kind = _bind_pydll("lucid_ds_iter_kind", c_char_p, [c_void_p])
_ds_iter_key_id = _bind_pydll("lucid_ds_iter_key_id", c_char_p, [c_void_p])
_ds_iter_rekey_state = _bind_pydll("lucid_ds_iter_rekey_state", c_char_p, [c_void_p])
_ds_iter_destroy = _bind_pydll("lucid_ds_iter_destroy", None, [c_void_p])

# ── Connect: external file operations ─────────────────────────────────
_connect_link = _bind(
    "lucid_connect_link_file", c_int,
    [c_void_p, c_char_p, c_char_p, c_char_p, c_int64, c_char_p],
)
_connect_unlink = _bind("lucid_connect_unlink_file", c_int, [c_void_p, c_char_p])
_connect_link_http = _bind(
    "lucid_connect_link_http_file", c_int, [c_void_p, c_char_p, c_char_p, c_int64],
)
_connect_update_http_url = _bind(
    "lucid_connect_update_http_file_url", c_int, [c_void_p, c_char_p, c_char_p, c_int64],
)
_connect_count = _bind("lucid_connect_count_external_files", c_uint64, [c_void_p, c_char_p])

# ── Connect: external file listing ────────────────────────────────────
_connect_list_ef = _bind(
    "lucid_connect_list_external_files", c_void_p,
    [c_void_p, c_char_p, c_uint32, c_char_p],
)
_ef_iter_next = _bind_pydll("lucid_ef_iter_next", c_int, [c_void_p])
_ef_iter_path = _bind_pydll("lucid_ef_iter_path", c_char_p, [c_void_p])
_ef_iter_file_id = _bind_pydll("lucid_ef_iter_file_id", c_uint64, [c_void_p])
_ef_iter_has_more = _bind_pydll("lucid_ef_iter_has_more", c_int, [c_void_p])
_ef_iter_cursor = _bind_pydll("lucid_ef_iter_cursor", c_char_p, [c_void_p])
_ef_iter_destroy = _bind_pydll("lucid_ef_iter_destroy", None, [c_void_p])


class Connect(_NativeHandleOwner):
    """LucidLink Connect (external files / data stores) operations."""

    def __init__(self, connect_handle):
        self._c = connect_handle

    def are_data_stores_available(self):
        return _check(_connect_are_data_stores_available(self._c), -1) == 1

    def add_data_store(
        self, name, access_key, secret_key, bucket_name, region,
        endpoint="", url_expiration_minutes=10080, use_virtual_addressing=False,
    ):
        _check(
            _connect_add_ds(
                self._c, name.encode(), access_key.encode(), secret_key.encode(),
                bucket_name.encode(), region.encode(), (endpoint or "").encode(),
                url_expiration_minutes, 1 if use_virtual_addressing else 0,
            ),
            -1,
        )
        # The C ABI's add returns only success/failure; fetch the new store
        # so the caller gets a full DataStoreInfo dict.
        return self.get_data_store(name)

    def remove_data_store(self, name):
        _check(_connect_remove_ds(self._c, name.encode()), -1)

    def _ds_iter_to_dict(self, it):
        """Build a data-store dict from the iterator at its current position."""
        return {
            "name": _ds_iter_name(it).decode(),
            "access_key": _ds_iter_access_key(it).decode(),
            "secret_key": _ds_iter_secret_key(it).decode(),
            "bucket_name": _ds_iter_bucket(it).decode(),
            "region": _ds_iter_region(it).decode(),
            "endpoint": _ds_iter_endpoint(it).decode(),
            "url_expiration_minutes": _ds_iter_url_expiration(it),
            "use_virtual_addressing": bool(_ds_iter_use_virtual_addressing(it)),
            "kind": _ds_iter_kind(it).decode(),
            "key_id": _ds_iter_key_id(it).decode(),
            "rekey_state": _ds_iter_rekey_state(it).decode(),
        }

    def list_data_stores(self):
        it = _check(_connect_list_ds(self._c), None)
        try:
            stores = []
            while _ds_iter_next(it) == 1:
                stores.append(self._ds_iter_to_dict(it))
            return stores
        finally:
            _ds_iter_destroy(it)

    def get_data_store(self, name):
        # Use the dedicated get-by-name C ABI which populates secret_key
        # (list_data_stores leaves it empty by design).
        it = _check(_connect_get_ds(self._c, name.encode()), None)
        try:
            if _ds_iter_next(it) != 1:
                return None
            return self._ds_iter_to_dict(it)
        finally:
            _ds_iter_destroy(it)

    def rekey_data_store(self, name, new_access_key, new_secret_key):
        _check(
            _connect_rekey_ds(
                self._c, name.encode(), new_access_key.encode(), new_secret_key.encode(),
            ),
            -1,
        )

    def link_file(self, file_path, data_store_name, object_id, size=None, checksum=""):
        sz = size if size is not None else -1
        _check(
            _connect_link(
                self._c, _encode_path(file_path), data_store_name.encode(),
                object_id.encode(), sz, (checksum or "").encode(),
            ),
            -1,
        )

    def unlink_file(self, file_path):
        _check(_connect_unlink(self._c, _encode_path(file_path)), -1)

    def link_http_file(self, file_path, url, size=None):
        sz = size if size is not None else -1
        _check(_connect_link_http(self._c, _encode_path(file_path), url.encode(), sz), -1)

    def update_http_file_url(self, file_path, new_url, size=None):
        sz = size if size is not None else -1
        _check(_connect_update_http_url(self._c, _encode_path(file_path), new_url.encode(), sz), -1)

    def count_external_files(self, data_store_name):
        return _connect_count(self._c, data_store_name.encode())

    def list_external_files(self, data_store_name, limit=100, cursor=""):
        it = _check(
            _connect_list_ef(
                self._c, data_store_name.encode(), limit, (cursor or "").encode(),
            ),
            None,
        )
        try:
            file_paths = []
            file_ids = []
            while _ef_iter_next(it) == 1:
                file_paths.append(_ef_iter_path(it).decode())
                file_ids.append(_ef_iter_file_id(it))
            return {
                "file_paths": file_paths,
                "file_ids": file_ids,
                "has_more": bool(_ef_iter_has_more(it)),
                "cursor": _ef_iter_cursor(it).decode() if _ef_iter_cursor(it) else "",
            }
        finally:
            _ef_iter_destroy(it)

    def __del__(self):
        try:
            if getattr(self, "_c", None):
                _connect_destroy(self._c)
                self._c = None
        except Exception:
            pass
