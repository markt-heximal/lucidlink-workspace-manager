"""
Daemon class and its C ABI bindings.

Covers: daemon lifecycle, authentication, workspace identity, filespace
listing iterator, filespace link/unlink, and the get_connect bridge into
the Connect surface. Mirrors the C side at ``Sdk/Api/lucid_api_daemon.cpp``.
"""

import ctypes
import json
import os
from ctypes import c_char_p, c_int, c_int64, c_uint64, c_void_p

from ._connect import Connect, _get_connect
from ._errors import _check
from ._filesystem import FileSystem
from ._helpers import _NativeHandleOwner, _free
from ._loader import _bind_pydll

# Daemon bindings use _bind_pydll (PyDLL) so the GIL is held across the
# native call. This serializes Python-side state mutations on the Daemon
# instance — two threads cannot simultaneously enter authenticate() /
# link_filespace() / unlink_filespace() / get_connect() and race on
# _workspace_handle, _fs_handle, or _connect.

# ── Daemon lifecycle ──────────────────────────────────────────────────
_daemon_create = _bind_pydll("lucid_daemon_create", c_void_p, [c_char_p])
_daemon_start = _bind_pydll("lucid_daemon_start", c_int, [c_void_p])
_daemon_stop = _bind_pydll("lucid_daemon_stop", c_int, [c_void_p])
_daemon_destroy = _bind_pydll("lucid_daemon_destroy", None, [c_void_p])
_daemon_is_running = _bind_pydll("lucid_daemon_is_running", c_int, [c_void_p])
_daemon_get_status = _bind_pydll("lucid_daemon_get_status", c_void_p, [c_void_p])

# ── Authentication / workspace ────────────────────────────────────────
_authenticate = _bind_pydll("lucid_authenticate", c_void_p, [c_void_p, c_char_p])
_workspace_id = _bind_pydll("lucid_workspace_id", c_char_p, [c_void_p])
_workspace_name = _bind_pydll("lucid_workspace_name", c_char_p, [c_void_p])
_workspace_destroy = _bind_pydll("lucid_workspace_destroy", None, [c_void_p])

# ── Filespace listing ─────────────────────────────────────────────────
_list_filespaces = _bind_pydll("lucid_list_filespaces", c_void_p, [c_void_p])
_fs_iter_next = _bind_pydll("lucid_fs_iter_next", c_int, [c_void_p])
_fs_iter_id = _bind_pydll("lucid_fs_iter_id", c_char_p, [c_void_p])
_fs_iter_name = _bind_pydll("lucid_fs_iter_name", c_char_p, [c_void_p])
_fs_iter_created = _bind_pydll("lucid_fs_iter_created", c_char_p, [c_void_p])
_fs_iter_size = _bind_pydll("lucid_fs_iter_size", c_int64, [c_void_p])
_fs_iter_destroy = _bind_pydll("lucid_fs_iter_destroy", None, [c_void_p])

# ── Filespace linking ─────────────────────────────────────────────────
_link_filespace = _bind_pydll("lucid_link_filespace", c_void_p, [c_void_p, c_char_p, c_char_p])
_unlink_filespace = _bind_pydll("lucid_unlink_filespace", c_int, [c_void_p])
_filespace_destroy = _bind_pydll("lucid_filespace_destroy", None, [c_void_p])


class Daemon(_NativeHandleOwner):
    """LucidLink Daemon — lifecycle, authentication, filespace linking."""

    def __init__(self, config):
        ws_url = os.environ.get("LUCIDLINK_WEBSERVICE_URL", "")
        if ws_url:
            config["webservice.url"] = ws_url
        config_json = json.dumps(config)
        self._handle = _check(_daemon_create(config_json.encode()), None)
        self._workspace_handle = None
        self._fs_handle = None
        self._connect = None

    def start(self):
        _check(_daemon_start(self._handle), -1)

    def stop(self):
        _check(_daemon_stop(self._handle), -1)

    def is_running(self):
        return _daemon_is_running(self._handle) == 1

    def is_linked(self):
        return self.get_status().get("linked") == "true"

    def authenticate(self, token):
        if not token:
            raise ValueError("Service account token cannot be empty")
        self._workspace_handle = _check(
            _authenticate(self._handle, token.encode()), None
        )
        return {
            "workspace_id": _workspace_id(self._workspace_handle).decode(),
            "workspace_name": _workspace_name(self._workspace_handle).decode(),
        }

    def list_filespaces(self, workspace_id):
        if not self._workspace_handle:
            raise RuntimeError("Not authenticated")
        it = _check(_list_filespaces(self._workspace_handle), None)
        try:
            result = []
            while _fs_iter_next(it) == 1:
                result.append({
                    "id": _fs_iter_id(it).decode(),
                    "name": _fs_iter_name(it).decode(),
                    "created": _fs_iter_created(it).decode(),
                    "size": _fs_iter_size(it),
                })
            return result
        finally:
            _fs_iter_destroy(it)

    def link_filespace(self, workspace_id, filespace_name, filespace_id, root_path):
        # workspace_id and root_path are accepted but unused: the C ABI derives
        # them from the workspace handle and always uses "/" as the root.
        if not self._workspace_handle:
            raise RuntimeError(
                "Not authenticated. Call authenticate() with service account token first."
            )
        self._fs_handle = _check(
            _link_filespace(
                self._workspace_handle, filespace_name.encode(), filespace_id.encode(),
            ),
            None,
        )
        return FileSystem(self._fs_handle)

    def unlink_filespace(self):
        if not self._workspace_handle:
            return
        # lucid_unlink_filespace disconnects the filespace logically but
        # leaves the heap-allocated lucid_filespace struct alive. The finally
        # block ensures the struct is freed even if unlink raises — otherwise
        # the handle would leak until Daemon teardown.
        try:
            _check(_unlink_filespace(self._workspace_handle), -1)
        finally:
            # Connect: just drop Daemon's reference. The lucid_connect struct
            # holds a weak_ptr to the C++ Connect; once we unlink, lock() fails
            # and the C ABI surfaces a clean "Connect has been destroyed" error
            # on any subsequent call from an external reference. Destroying
            # here would replace that informative error with a NULL-handle
            # error and defeat the weak_ptr design on purpose.
            self._connect = None
            if self._fs_handle:
                _filespace_destroy(self._fs_handle)
                self._fs_handle = None

    def get_status(self):
        raw = _daemon_get_status(self._handle)
        if not raw:
            return {}
        try:
            decoded = ctypes.cast(raw, c_char_p).value.decode()
        finally:
            _free(raw)
        if not decoded:
            return {}
        return json.loads(decoded)

    def get_connect(self):
        if not self._fs_handle:
            raise RuntimeError("Not linked to filespace")
        if self._connect is None:
            c = _check(_get_connect(self._fs_handle), None)
            self._connect = Connect(c)
        return self._connect

    def __del__(self):
        try:
            # Free any still-alive filespace/workspace handles before tearing
            # down the daemon — they're heap-allocated structs that won't be
            # reclaimed by lucid_daemon_destroy alone.
            if getattr(self, "_fs_handle", None):
                _filespace_destroy(self._fs_handle)
                self._fs_handle = None
            if getattr(self, "_workspace_handle", None):
                _workspace_destroy(self._workspace_handle)
                self._workspace_handle = None
            if getattr(self, "_handle", None):
                _daemon_destroy(self._handle)
                self._handle = None
        except Exception:
            pass
