"""
Error parsing and Python exception mapping for the liblucid C ABI.

Categorized C exceptions (those prefixed with the SOH/STX sentinel pair) get
mapped to specific Python exception classes via ``_EXCEPTION_MAP``. Uncategorized
errors fall through to a generic ``RuntimeError``. ``_check`` is the single
entry point used by every C-call wrapper across the shim.
"""

import errno as _errno
from ctypes import c_char_p

from ._loader import _bind

_last_error = _bind("lucid_last_error", c_char_p, [])
_clear_error = _bind("lucid_clear_error", None, [])

# Map values are either:
#   - a Python exception class (constructed as cls(err)), or
#   - a tuple (OSError-subclass, errno_code) for system-error-style mapping
#     (constructed as cls(errno_code, err) so .errno is populated).
#
# Insertion order matters: leaf entries must appear before their base-class
# entries so a leaf match isn't shadowed. The full set mirrors master's
# pybind11 translator (PythonExceptionTranslator.cpp) catch ladder.
_EXCEPTION_MAP = {
    # FS leaves (Category A — args[0] adds path/name context)
    "InvalidPathException": FileNotFoundError,
    "FileExistsException": FileExistsError,
    "DirExistsException": FileExistsError,
    "NotDirException": NotADirectoryError,
    # FS leaves (Category B)
    "IsDirException": IsADirectoryError,
    "DirNotEmptyException": (OSError, _errno.ENOTEMPTY),
    "FileReadOnlyException": PermissionError,
    "CannotCreateEntryException": RuntimeError,
    "SymlinkTooDeepException": OSError,
    # HTTP store (thrown directly from HTTP backends)
    "HttpStoreClientException": ConnectionError,
    # FS base catch — picks up HttpLinkFileException et al.
    "FileSystemException": OSError,
    # Authentication / authorization
    "WrongCredentialsException": PermissionError,
    "NoFilespacePermissionsException": PermissionError,
    "AuthorizationException": PermissionError,
    "UnauthorizedException": PermissionError,
    "InvalidSessionException": RuntimeError,
    "ScramException": PermissionError,
    "CryptoException": RuntimeError,
    # Config / argument
    "InvalidConfigException": ValueError,
    "InvalidArgumentException": ValueError,
    "InvalidKeyException": KeyError,
    "InvalidStateException": RuntimeError,
    # Network
    "TimeoutException": TimeoutError,
    "TransportException": ConnectionError,
    "HttpException": RuntimeError,
    "IoException": IOError,
    # Data stores
    "DataStoreNotFoundException": KeyError,
    "DataStoreAlreadyExistsException": FileExistsError,
    "DataStoreHasLinkedFilesException": RuntimeError,
    "DataStoresException": RuntimeError,
    "LockingException": RuntimeError,
    # Lifecycle / version / fatal
    "NotImplementedException": NotImplementedError,
    "TerminateClientException": SystemExit,
    "OperationCancelledException": RuntimeError,
    "InitException": RuntimeError,
    "InternalErrorException": RuntimeError,
    "ServiceException": RuntimeError,
    "NotEnoughDiskSpaceException": (OSError, _errno.ENOSPC),
    "SystemException": OSError,
    "FilespaceVersionException": RuntimeError,
    "KeyStackVersionException": RuntimeError,
    "ClientVersionException": RuntimeError,
    "ClientRejectedException": RuntimeError,
    "DataCorruptedException": RuntimeError,
    "MetadataCorruptedException": RuntimeError,
    "FilespaceStartupException": RuntimeError,
    "ConflictException": RuntimeError,
    "AssertionFailedException": AssertionError,
}

# Sentinel characters wrapping the exception category at the start of the C
# error string — see SetErrorFromException in lucid_api_error.cpp. The pair is
# delivered in a single lucid_last_error() call (atomic at the FFI boundary);
# a separate accessor could desync if any other C call slipped in between.
_CAT_START = "\x01"
_CAT_END = "\x02"


def _parse_error(raw_bytes):
    """Return (category, message). Category is '' for unprefixed plain errors."""
    err = raw_bytes.decode() if raw_bytes else ""
    if err.startswith(_CAT_START):
        end = err.find(_CAT_END, 1)
        if end != -1:
            return err[1:end], err[end + 1:]
    return "", err


def _check(result, fail_val):
    if result == fail_val:
        category, err = _parse_error(_last_error())
        mapping = _EXCEPTION_MAP.get(category) if category else None
        if mapping is not None:
            if isinstance(mapping, tuple):
                cls, errno_code = mapping
                raise cls(errno_code, err)
            raise mapping(err)
        # Plain errors (no category) and unknown categories fall through.
        if "empty" in err.lower():
            raise ValueError(err)
        raise RuntimeError(err or "Unknown liblucid error")
    return result
