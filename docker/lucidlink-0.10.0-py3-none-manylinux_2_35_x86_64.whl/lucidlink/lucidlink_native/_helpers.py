"""
Small cross-class helpers: path encoding and the lucid_free binding.

``_free`` lives here (rather than in ``_filesystem``) because both
``FileSystem.read_symlink`` and ``Daemon.get_status`` need to release
heap-allocated C strings returned by the library.
"""

from ctypes import c_void_p

from ._loader import _bind

_free = _bind("lucid_free", None, [c_void_p])


class _NativeHandleOwner:
    # Copying any wrapper around a raw C handle either double-frees the
    # underlying struct (owners) or lets the copy outlive its owner and
    # dereference a stale pointer (non-owners). Forbid all copy/serialize paths.
    def __copy__(self):
        raise TypeError(f"{type(self).__name__} cannot be copied; it wraps a native handle.")

    def __deepcopy__(self, memo):
        raise TypeError(f"{type(self).__name__} cannot be deep-copied; it wraps a native handle.")

    def __reduce_ex__(self, protocol):
        raise TypeError(f"{type(self).__name__} cannot be pickled; it wraps a native handle.")


def _encode_path(path):
    # Argument validation at the FFI boundary — see plan §Non-Functional Requirements.
    if path is None:
        raise TypeError("path cannot be None")
    if isinstance(path, bytes):
        data = path
    else:
        try:
            data = path.encode("utf-8")
        except (AttributeError, UnicodeEncodeError) as e:
            raise ValueError(f"path is not UTF-8 encodable: {e}") from e
    if b"\x00" in data:
        raise ValueError("path contains embedded null byte")
    return data
