"""
LucidLink Python Library - Filespace Type Definitions

Types for filespace identity, configuration, and daemon status.
"""

from dataclasses import dataclass
from enum import Enum


class SyncMode(Enum):
    """Controls whether changes are automatically synchronized to the hub on close."""

    SYNC_NONE = "none"
    """Do not sync automatically — caller must call ``sync_all()`` explicitly."""

    SYNC_ALL = "all"
    """(default) Automatically call ``sync_all()`` before unlinking filespaces."""


@dataclass
class FilespaceInfo:
    """Summary information for a filespace in a workspace listing.

    Returned by ``Workspace.list_filespaces()``.
    """

    id: str
    """Unique filespace identifier."""

    name: str
    """Human-readable filespace name."""

    created: str
    """Creation timestamp (ISO 8601)."""


@dataclass
class DaemonStatus:
    """Daemon status information.

    Returned by ``Daemon.get_status()``.
    """

    is_running: bool
    """Whether the daemon is currently running."""

    is_authenticated: bool
    """Whether the daemon has authenticated to a workspace."""

    is_linked: bool
    """Whether the daemon is linked to a filespace."""

    root_path: str
    """Root path for daemon operational files."""
