"""URL parsing utilities for LucidLink filesystem paths.

Handles parsing and manipulation of lucidlink:// protocol URLs.
"""

from dataclasses import dataclass
from typing import Tuple

try:
    from fsspec.utils import stringify_path
    FSSPEC_AVAILABLE = True
except ImportError:
    FSSPEC_AVAILABLE = False

    def stringify_path(path):
        """Fallback for when fsspec is not available."""
        return str(path)


PROTOCOL = "lucidlink"
PROTOCOL_PREFIX = f"{PROTOCOL}://"


@dataclass(frozen=True)
class ParsedUrl:
    """Parsed components of a lucidlink:// URL.

    Attributes:
        workspace: Workspace name
        filespace: Filespace name
        path: File path within the filespace (always starts with '/')
    """

    workspace: str
    filespace: str
    path: str

    @property
    def cache_key(self) -> str:
        """Get the cache key for filespace connections."""
        return f"{self.workspace}/{self.filespace}"

    def with_path(self, new_path: str) -> "ParsedUrl":
        """Create a new ParsedUrl with a different path."""
        return ParsedUrl(self.workspace, self.filespace, new_path)

    def to_url(self) -> str:
        """Convert back to a lucidlink:// URL."""
        path_suffix = self.path.lstrip("/")
        if path_suffix:
            return f"{PROTOCOL_PREFIX}{self.workspace}/{self.filespace}/{path_suffix}"
        return f"{PROTOCOL_PREFIX}{self.workspace}/{self.filespace}"


class UrlParser:
    """Parser for lucidlink:// protocol URLs.

    Parses URLs in the format:
        lucidlink://workspace/filespace/path/to/file.txt

    Example:
        .. code-block:: python

            parser = UrlParser()
            parsed = parser.parse("lucidlink://my-workspace/prod-data/files/doc.txt")
            print(parsed.workspace)   # 'my-workspace'
            print(parsed.filespace)   # 'prod-data'
            print(parsed.path)        # '/files/doc.txt'
    """

    def parse(self, url: str) -> ParsedUrl:
        """Parse a lucidlink:// URL into components.

        Args:
            url: URL like 'lucidlink://workspace/filespace/path/to/file.txt'

        Returns:
            ParsedUrl with workspace, filespace, and path components

        Raises:
            ValueError: If URL format is invalid
        """
        path = stringify_path(url)
        path = self._strip_protocol(path)
        return self._parse_path(path, original_url=url)

    def _strip_protocol(self, path: str) -> str:
        """Remove protocol prefix from path."""
        if path.startswith(PROTOCOL_PREFIX):
            return path[len(PROTOCOL_PREFIX) :]
        if path.startswith("//"):
            return path[2:]
        return path

    def _parse_path(self, path: str, original_url: str) -> ParsedUrl:
        """Parse path components after protocol is stripped."""
        parts = path.split("/", 2)

        if len(parts) < 2:
            raise ValueError(
                f"Invalid LucidLink URL: {original_url}. "
                f"Expected format: {PROTOCOL_PREFIX}workspace/filespace/path"
            )

        workspace = parts[0]
        filespace = parts[1]
        file_path = "/" + parts[2] if len(parts) > 2 else "/"

        return ParsedUrl(workspace, filespace, file_path)

    def validate_same_filespace(self, url1: str, url2: str) -> Tuple[ParsedUrl, ParsedUrl]:
        """Validate that two URLs are in the same filespace.

        Args:
            url1: First URL
            url2: Second URL

        Returns:
            Tuple of parsed URLs

        Raises:
            ValueError: If URLs are in different filespaces
        """
        parsed1 = self.parse(url1)
        parsed2 = self.parse(url2)

        if parsed1.workspace != parsed2.workspace or parsed1.filespace != parsed2.filespace:
            raise ValueError(
                f"Cannot operate across different filespaces: "
                f"{parsed1.workspace}/{parsed1.filespace} -> "
                f"{parsed2.workspace}/{parsed2.filespace}"
            )

        return parsed1, parsed2

    def build_full_path(self, base_url: str, child_name: str) -> str:
        """Build a full URL by appending a child name to a base URL.

        Args:
            base_url: Base lucidlink:// URL (trailing slash optional)
            child_name: Name to append (not a full path)

        Returns:
            Full URL with child appended
        """
        base = base_url.rstrip("/")
        return f"{base}/{child_name}"
