"""
LucidLink Python Library - Filesystem Type Definitions

Types for filesystem entries, sizes, and statistics.
"""

from dataclasses import dataclass


@dataclass
class DirEntry:
    """Represents a file or directory entry in the filesystem.

    Returned by ``Filesystem.read_dir()`` and ``Filesystem.get_entry()``.
    """

    name: str
    """Name of the file/directory (without path)."""

    size: int
    """Size in bytes (0 for directories)."""

    type: str
    """Entry type string (``"file"``, ``"dir"``, ``"link"``, ``"unknown"``)."""

    file_id: str
    """Unique file identifier."""

    file_id_external: int
    """External file identifier."""

    ctime: int
    """Creation time (Unix timestamp)."""

    mtime: int
    """Last modification time (Unix timestamp)."""

    def is_file(self) -> bool:
        """Check if this entry is a regular file."""
        return self.type == "file"

    def is_dir(self) -> bool:
        """Check if this entry is a directory."""
        return self.type == "dir"

    def is_link(self) -> bool:
        """Check if this entry is a symbolic link."""
        return self.type == "link"

    def __str__(self) -> str:
        return f"{self.type}: {self.name} ({self.size} bytes)"


@dataclass
class FilespaceSize:
    """Filespace size information.

    Returned by ``Filesystem.get_size()``.
    """

    entries: int
    """Size of metadata entries in bytes."""

    data: int
    """Size of file data in bytes."""

    storage: int
    """Total storage used in bytes."""

    external_files_size: int
    """Size of external (Connect) files in bytes."""

    external_files_count: int
    """Number of external (Connect) files."""

    def __str__(self) -> str:
        return (f"FilespaceSize(entries={self.entries}, "
                f"data={self.data}, "
                f"storage={self.storage})")


@dataclass
class FilespaceStatistics:
    """Filespace statistics.

    Returned by ``Filesystem.get_statistics()``.
    """

    file_count: int
    """Number of files in the filespace."""

    directory_count: int
    """Number of directories in the filespace."""

    symlink_count: int
    """Number of symbolic links in the filespace."""

    entries_size: int
    """Size of metadata entries in bytes."""

    data_size: int
    """Size of file data in bytes."""

    storage_size: int
    """Total storage used in bytes."""

    external_files_size: int
    """Size of external (Connect) files in bytes."""

    external_files_count: int
    """Number of external (Connect) files."""

    def __str__(self) -> str:
        return (f"FilespaceStatistics(files={self.file_count}, "
                f"directories={self.directory_count}, "
                f"symlinks={self.symlink_count})")
