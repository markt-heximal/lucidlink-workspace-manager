"""Helpers for redacting sensitive values when rendering objects via ``repr``."""

import dataclasses
from typing import Any, Callable, Dict


VALID_TOKEN_PREFIXES = ("lucid_sa", "sa_live", "sa_dev", "sa_staging", "sa_local")


def redact_service_account_token(token: str) -> str:
    """Return the token with everything after the prefix replaced by ``***``.

    Falls back to ``lucid_sa`` when the prefix is missing or unrecognised, so a
    malformed token never leaks bytes through its prefix.
    """
    candidate = token.split(":", 1)[0] if ":" in token else ""
    prefix = candidate if candidate in VALID_TOKEN_PREFIXES else "lucid_sa"
    return f"{prefix}:***"


def _redact_token_field(value: Any) -> str:
    if not value:
        return repr(value)
    return repr(redact_service_account_token(value))


def _redact_secret_field(value: Any) -> str:
    return repr("<redacted>" if value else "")


_REDACTORS: Dict[str, Callable[[Any], str]] = {
    "token": _redact_token_field,
    "secret_key": _redact_secret_field,
    "secret_access_key": _redact_secret_field,
}


def redacted_dataclass_repr(instance: Any) -> str:
    """Drop-in ``__repr__`` for dataclasses; redacts fields named in :data:`_REDACTORS`.

    Honors ``field(repr=False)``.
    """
    parts = []
    for f in dataclasses.fields(instance):
        if not f.repr:
            continue
        value = getattr(instance, f.name)
        redactor = _REDACTORS.get(f.name)
        rendered = redactor(value) if redactor else repr(value)
        parts.append(f"{f.name}={rendered}")
    return f"{type(instance).__name__}({', '.join(parts)})"
