"""
Workspace context after successful authentication.
"""

from typing import List, Optional

from .models import FilespaceInfo


class Workspace:
    """
    Workspace context after successful authentication.

    Provides access to filespace operations within the authenticated workspace.
    This object is returned by Daemon.authenticate() and carries the authentication
    context needed for filespace operations.

    Properties:
        id: Unique workspace identifier (read-only)
        name: Human-readable workspace name (read-only)

    Example:
        >>> credentials = ServiceAccountCredentials(token)
        >>> workspace = daemon.authenticate(credentials)
        >>> print(workspace.id, workspace.name)
        'ws-12345' 'Production Workspace'
    """

    def __init__(self, native_daemon, workspace_id: str, workspace_name: str):
        """
        Initialize workspace context.

        Args:
            native_daemon: Native daemon wrapper (internal use)
            workspace_id: Workspace ID
            workspace_name: Workspace name

        Note: This constructor is called internally by Daemon.authenticate().
              Users should not construct Workspace objects directly.
        """
        self._native_daemon = native_daemon
        self._id = workspace_id
        self._name = workspace_name

    @property
    def id(self) -> str:
        """Get the workspace ID."""
        return self._id

    @property
    def name(self) -> str:
        """Get the workspace name."""
        return self._name

    def list_filespaces(self) -> List[FilespaceInfo]:
        """
        List all filespaces in this workspace.

        Returns:
            List of FilespaceInfo objects with id, name, and created timestamp.

        Raises:
            ConnectionError: If WebService unreachable
            AuthenticationError: If access token expired
            RuntimeError: If daemon not running

        Example:
            >>> filespaces = workspace.list_filespaces()
            >>> for fs in filespaces:
            ...     print(f"{fs.name}")
        """
        return [
            FilespaceInfo(id=d["id"], name=d["name"], created=d["created"])
            for d in self._native_daemon.list_filespaces(self.id)
        ]

    def link_filespace(
        self,
        name: Optional[str] = None,
        id: Optional[str] = None,
        root_path: str = "/"
    ):
        """
        Link to a filespace in this workspace.

        You must provide either 'name' OR 'id', but not both.

        Args:
            name: Filespace name (either name or id required)
            id: Filespace ID (either name or id required)
            root_path: Mount point path (default: "/")

        Returns:
            Filespace object for filesystem operations

        Raises:
            ValueError: If neither name nor id provided, or both provided
            FileNotFoundError: If filespace not found
            PermissionDeniedError: If service account lacks access
            RuntimeError: If daemon not running or not authenticated

        Examples:
            Link by name (user-friendly):
            >>> fs = workspace.link_filespace(name="production-data")

            Link by ID (efficient if you have the UUID):
            >>> fs = workspace.link_filespace(id="fs-uuid-12345")

            Link to custom mount point:
            >>> fs = workspace.link_filespace(name="data", root_path="/mnt/lucid")
        """
        if name is None and id is None:
            raise ValueError("Must provide either 'name' or 'id'")
        if name is not None and id is not None:
            raise ValueError("Cannot provide both 'name' and 'id'")

        # Import here to avoid circular dependency
        from .filespace import Filespace

        native_fs = self._native_daemon.link_filespace(
            workspace_id=self.id,
            filespace_name=name if name else "",
            filespace_id=id if id else "",
            root_path=root_path
        )

        return Filespace(
            native_fs=native_fs,
            native_daemon=self._native_daemon,
            workspace_id=self._id,
            workspace_name=self._name,
            id=native_fs.get_id() or "",
            full_name=native_fs.get_name() or ""
        )

    def __repr__(self) -> str:
        return f"Workspace(id='{self.id}', name='{self.name}')"
