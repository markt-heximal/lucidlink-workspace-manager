"""Filespace context after successful link.

Provides access to filesystem operations and external file management
on a linked LucidLink filespace.
"""

from typing import Optional

from .connect import ConnectManager
from .filesystem import Filesystem


class Filespace:
    """
    Filespace context after successful link.

    Provides identity, filesystem access via the .fs property, and
    external file operations via the .connect property.

    Properties:
        workspace_id: Workspace identifier (read-only)
        workspace_name: Workspace name (read-only)
        id: Unique filespace identifier (read-only)
        name: Short filespace name (first segment before dot) (read-only)
        full_name: Full filespace name (read-only)
        fs: Filesystem operations interface (read-only)
        connect: External file operations interface (read-only)

    Example:
        >>> filespace = workspace.link_filespace(name="production-data")
        >>> entries = filespace.fs.read_dir("/")
        >>> filespace.fs.create_dir("/new-folder")
        >>> with filespace.fs.open("/file.txt", "wb") as f:
        ...     f.write(b"data")
    """

    def __init__(
        self,
        native_fs,
        native_daemon,
        workspace_id: str,
        workspace_name: str,
        id: str,
        full_name: str
    ):
        """
        Initialize filespace context.

        Args:
            native_fs: Native filesystem wrapper (internal use)
            native_daemon: Native daemon instance (internal use)
            workspace_id: Workspace identifier
            workspace_name: Workspace name
            id: Filespace unique identifier
            full_name: Full filespace name (may include workspace prefix)

        Note: This constructor is called internally by Workspace.link_filespace().
              Users should not construct Filespace objects directly.
        """
        self._native = native_fs
        self._native_daemon = native_daemon
        self._workspace_id = workspace_id
        self._workspace_name = workspace_name
        self._id = id
        self._full_name = full_name
        self._connect: Optional[ConnectManager] = None
        self._fs = Filesystem(native_fs)

    @property
    def workspace_id(self) -> str:
        """Get the workspace ID."""
        return self._workspace_id

    @property
    def workspace_name(self) -> str:
        """Get the workspace name."""
        return self._workspace_name

    @property
    def id(self) -> str:
        """Get the filespace ID."""
        return self._id

    @property
    def name(self) -> str:
        """Get the short filespace name (first segment before dot)."""
        return self._full_name.split(".", 1)[0]

    @property
    def full_name(self) -> str:
        """Get the full filespace name."""
        return self._full_name

    @property
    def fs(self) -> Filesystem:
        """Get the filesystem interface for file and directory operations.

        Returns:
            Filesystem object providing read_dir, write_file, open,
            and all other filesystem operations.

        Example:
            >>> filespace.fs.read_dir("/")
            >>> filespace.fs.write_file("/hello.txt", b"world")
        """
        return self._fs

    @property
    def connect(self) -> ConnectManager:
        """Get the Connect interface for external file operations.

        Provides access to data store management and external file linking.
        External files are read-only S3 objects mapped 1:1 as files in the filespace.

        Returns:
            ConnectManager for data store and external file operations

        Raises:
            RuntimeError: If Connect is not available (e.g., filespace version too old)

        Example:
            >>> connect = filespace.connect
            >>> connect.add_data_store("my-store", S3DataStoreConfig(...))
            >>> connect.link_file("/data/file.csv", "my-store", "path/to/file.csv")
        """
        if self._connect is None:
            native_connect = self._native_daemon.get_connect()
            self._connect = ConnectManager(native_connect)
        return self._connect

    def sync_all(self) -> None:
        """
        Synchronize all pending changes to the hub.

        Flushes all pending metadata and data changes to ensure they are
        propagated to the LucidHub and become visible to other clients.
        This is critical in asynchronous distributed systems.

        This covers all subsystems — filesystem operations, connect/external
        file changes, and any other pending metadata updates.

        Usage:
            Call this method after write operations (create, modify, delete)
            to guarantee changes are committed before reading them back or
            expecting them to be visible to other clients.

        Example:
            >>> filespace.fs.write_file("/test.txt", b"data")
            >>> filespace.sync_all()  # Ensure write is committed
            >>> # Now other clients can see the file

        Raises:
            RuntimeError: If sync fails
        """
        self._native.sync_all()

    def unlink(self) -> None:
        """
        Unlink from this filespace.

        After calling this method, the filespace object becomes invalid and
        cannot be used for filesystem operations.

        Raises:
            RuntimeError: If unlink fails
        """
        self._native_daemon.unlink_filespace()

    def __repr__(self) -> str:
        return f"Filespace(workspace='{self._workspace_name}', id='{self.id}', name='{self.name}')"
