"""Filespace connection caching for fsspec integration.

Manages the currently-linked filespace connection. Only one filespace
can be linked at a time (daemon constraint), so this is a single-entry
cache that unlinks the current filespace before linking a new one.
"""

from typing import Optional, TYPE_CHECKING

from .exceptions import LucidLinkError
from .url_parser import ParsedUrl

if TYPE_CHECKING:
    from .workspace import Workspace
    from .filespace import Filespace


class FilespaceCache:
    """Single-entry cache for the currently-linked filespace.

    The daemon can only be linked to one filespace at a time. This cache
    tracks that single connection and handles unlinking/relinking when
    the user accesses a different filespace.

    Example:
        >>> cache = FilespaceCache()
        >>> cache.set_workspace(workspace)
        >>> filespace = cache.get_or_connect(parsed_url)
        >>> # Same filespace returns cached connection
        >>> same = cache.get_or_connect(parsed_url)
        >>> # Different filespace unlinks current, links new
        >>> other = cache.get_or_connect(different_url)
    """

    def __init__(self):
        """Initialize an empty filespace cache."""
        self._workspace: Optional["Workspace"] = None
        self._current: Optional["Filespace"] = None
        self._current_key: Optional[str] = None

    def set_workspace(self, workspace: "Workspace") -> None:
        """Set the authenticated workspace context.

        Args:
            workspace: Authenticated workspace object
        """
        self._workspace = workspace

    @property
    def workspace(self) -> Optional["Workspace"]:
        """Get the current workspace context."""
        return self._workspace

    def get_or_connect(self, parsed_url: ParsedUrl) -> "Filespace":
        """Get cached filespace or unlink current and link new one.

        Args:
            parsed_url: Parsed URL containing workspace and filespace info

        Returns:
            Filespace object for the requested workspace/filespace

        Raises:
            LucidLinkError: If no workspace is set
            PermissionError: If token doesn't have access to requested workspace or filespace
        """
        cache_key = parsed_url.cache_key

        if cache_key == self._current_key and self._current is not None:
            return self._current

        if self._workspace is None:
            raise LucidLinkError("Workspace not authenticated")

        # Validate that the token has access to the requested workspace
        if parsed_url.workspace != self._workspace.name:
            raise PermissionError(
                f"Access denied: token does not have access to workspace '{parsed_url.workspace}'"
            )

        # Unlink current filespace before linking new one
        if self._current is not None:
            try:
                self._current.unlink()
            except Exception:
                pass

        try:
            filespace = self._workspace.link_filespace(name=parsed_url.filespace)
        except Exception as e:
            self._current = None
            self._current_key = None
            raise PermissionError(
                f"Access denied: cannot access filespace '{parsed_url.filespace}'"
            ) from e

        self._current = filespace
        self._current_key = cache_key

        return filespace

    def unlink_all(self) -> None:
        """Unlink the current filespace.

        Silently ignores errors during unlinking.
        """
        if self._current is not None:
            try:
                self._current.unlink()
            except Exception:
                pass

        self._current = None
        self._current_key = None

    def clear(self) -> None:
        """Clear the cache without unlinking.

        Use unlink_all() to properly disconnect before clearing.
        """
        self._current = None
        self._current_key = None
        self._workspace = None

    def __contains__(self, cache_key: str) -> bool:
        """Check if a filespace is cached."""
        return cache_key == self._current_key

    def __len__(self) -> int:
        """Return number of cached filespaces (0 or 1)."""
        return 1 if self._current is not None else 0

    def values(self):
        """Iterate over cached filespaces."""
        if self._current is not None:
            return [self._current]
        return []
