"""Validation and normalization for LucidLink Connect data store operations."""

import re
import unicodedata
from dataclasses import replace
from urllib.parse import urlparse

from .connect_models import S3DataStoreConfig

__all__ = [
    "normalize_data_store_name",
    "normalize_s3_data_store_config",
    "validate_data_store_name",
    "validate_bucket_name",
    "validate_region",
    "validate_access_key",
    "validate_secret_key",
    "validate_endpoint",
    "validate_data_store_count",
    "validate_s3_data_store",
    "validate_link_file_metadata",
]

MAX_DATA_STORE_NAME_LENGTH = 64
MAX_DATA_STORES_PER_FILESPACE = 1000
MIN_BUCKET_NAME_LENGTH = 3
MAX_BUCKET_NAME_LENGTH = 63

BUCKET_NAME_PATTERN_VIRTUAL = re.compile(r"^[\da-z]([\d.a-z-])*[\da-z]$")
BUCKET_NAME_PATTERN_PATH = re.compile(r"^[\da-z]([\d._a-z-])*[\da-z]$")
IP_ADDRESS_PATTERN = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")
VALID_REGION_PATTERN = re.compile(r"^[\da-z-]+$")

_ALLOWED_NAME_CATEGORIES = frozenset({
    "Lu", "Ll", "Lt", "Lm", "Lo",  # Letters
    "Mn", "Mc", "Me",              # Marks
    "Nd", "Nl", "No",              # Numbers
})
_ALLOWED_NAME_EXTRAS = frozenset(" _-")


def normalize_data_store_name(name: str) -> str:
    trimmed = name.strip()
    return unicodedata.normalize("NFD", trimmed)


def normalize_s3_data_store_config(config: S3DataStoreConfig) -> S3DataStoreConfig:
    return replace(
        config,
        access_key=config.access_key.strip(),
        secret_key=config.secret_key.strip(),
        endpoint=config.endpoint.strip(),
    )


def validate_data_store_name(name: str) -> None:
    if not name:
        raise ValueError("Data store name cannot be empty or whitespace-only")

    if len(name) > MAX_DATA_STORE_NAME_LENGTH:
        raise ValueError(
            f"Data store name must be at most {MAX_DATA_STORE_NAME_LENGTH} characters (got {len(name)})"
        )

    for ch in name:
        if ch not in _ALLOWED_NAME_EXTRAS and unicodedata.category(ch) not in _ALLOWED_NAME_CATEGORIES:
            raise ValueError(
                "Data store name can only contain letters, numbers, spaces, underscores, and hyphens"
            )


def validate_bucket_name(bucket_name: str, use_virtual_addressing: bool) -> None:
    if not bucket_name:
        raise ValueError("Bucket name cannot be empty")

    length = len(bucket_name)
    if length < MIN_BUCKET_NAME_LENGTH or length > MAX_BUCKET_NAME_LENGTH:
        raise ValueError(
            f"Bucket name must be between {MIN_BUCKET_NAME_LENGTH} and {MAX_BUCKET_NAME_LENGTH} characters (got {length})"
        )

    if use_virtual_addressing:
        if not BUCKET_NAME_PATTERN_VIRTUAL.match(bucket_name):
            raise ValueError(
                "Bucket name must contain only lowercase letters, numbers, dots, and hyphens, "
                "and must start and end with a letter or number"
            )
        if ".." in bucket_name:
            raise ValueError("Bucket name cannot contain consecutive dots")
        if _is_valid_ip_address(bucket_name):
            raise ValueError("Bucket name cannot be formatted as an IP address")
    else:
        if not BUCKET_NAME_PATTERN_PATH.match(bucket_name):
            raise ValueError(
                "Bucket name must contain only lowercase letters, numbers, dots, hyphens, and underscores, "
                "and must start and end with a letter or number"
            )


def validate_region(region: str, endpoint: str) -> None:
    has_region = bool(region and region.strip())
    has_endpoint = bool(endpoint and endpoint.strip())

    if not has_region and not has_endpoint:
        raise ValueError("Either region or endpoint must be provided")

    if has_region and not VALID_REGION_PATTERN.match(region):
        raise ValueError(
            "Region can only contain lowercase letters, numbers, and hyphens"
        )


def validate_access_key(access_key: str) -> None:
    if not access_key:
        raise ValueError("Access key cannot be empty")


def validate_secret_key(secret_key: str) -> None:
    if not secret_key:
        raise ValueError("Secret key cannot be empty")


def validate_endpoint(endpoint: str) -> None:
    if not endpoint or not endpoint.strip():
        return

    if "://" not in endpoint:
        parsed = urlparse(f"http://{endpoint}")
        if not parsed.hostname:
            raise ValueError(f"Invalid endpoint URL: {endpoint}")
    else:
        parsed = urlparse(endpoint)
        if not parsed.hostname:
            raise ValueError(f"Invalid endpoint URL: {endpoint}")
        if parsed.scheme not in ("http", "https"):
            raise ValueError(
                f"Endpoint must use http:// or https:// protocol (got {parsed.scheme}://)"
            )


def validate_data_store_count(current_count: int) -> None:
    if current_count >= MAX_DATA_STORES_PER_FILESPACE:
        raise ValueError("Maximum number of data stores reached.")


def validate_s3_data_store(config: S3DataStoreConfig) -> None:
    validate_bucket_name(config.bucket_name, config.use_virtual_addressing)
    validate_region(config.region, config.endpoint)
    validate_access_key(config.access_key)
    validate_secret_key(config.secret_key)
    validate_endpoint(config.endpoint)


def validate_link_file_metadata(size: "int | None", checksum: str) -> None:
    has_size = size is not None
    has_checksum = bool(checksum)
    if has_size != has_checksum:
        raise ValueError("size and checksum must be provided together")


def _is_valid_ip_address(value: str) -> bool:
    if not IP_ADDRESS_PATTERN.match(value):
        return False
    parts = value.split(".")
    return len(parts) == 4 and all(0 <= int(p) <= 255 for p in parts)
