"""
Service account credentials for LucidLink authentication.
"""


class ServiceAccountCredentials:
    """
    Service account authentication credentials.

    Service account tokens are generated from WebClient or BackOffice and provide
    programmatic access to LucidLink workspaces and filespaces.

    Token format: lucid_sa:<webServiceToken>:<secretKey> or sa_live:<webServiceToken>:<secretKey>

    Example:
        >>> token = "lucid_sa:abc123...:xyz789..."
        >>> credentials = ServiceAccountCredentials(token)
        >>> workspace = daemon.authenticate(credentials)
    """

    def __init__(self, token: str):
        """
        Initialize service account credentials.

        Args:
            token: Service account token (format: lucid_sa:webServiceToken:secretKey or sa_live:webServiceToken:secretKey)

        Raises:
            ValueError: If token format is invalid
        """
        if not token:
            raise ValueError("Service account token cannot be empty")

        valid_prefixes = ("lucid_sa:", "sa_live:", "sa_dev:", "sa_staging:", "sa_local:")
        if not any(token.startswith(p) for p in valid_prefixes):
            raise ValueError("Invalid service account token format.")

        # Basic validation: must have at least 2 colons
        parts = token.split(":")
        if len(parts) < 3:
            raise ValueError("Invalid service account token format.")

        self.token = token

    def __repr__(self) -> str:
        # Don't expose the full token in repr for security
        prefix = self.token.split(":")[0] if ":" in self.token else "lucid_sa"
        return f"ServiceAccountCredentials(token='{prefix}:***')"
