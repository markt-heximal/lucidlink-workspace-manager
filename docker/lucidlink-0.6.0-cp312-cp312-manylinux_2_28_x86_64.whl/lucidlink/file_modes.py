"""File mode utilities for LucidLink file operations.

Provides consistent mode parsing and normalization across the library.
"""

from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class ParsedMode:
    """Parsed file mode components.

    Attributes:
        is_read: True if mode allows reading
        is_write: True if mode allows writing
        is_append: True if mode is append
        is_update: True if mode allows both read and write ('+')
        is_text: True if text mode
        is_binary: True if binary mode
        cpp_mode: Simplified mode string for C++ layer ('r', 'w', or 'a')
    """

    is_read: bool
    is_write: bool
    is_append: bool
    is_update: bool
    is_text: bool
    is_binary: bool

    @property
    def cpp_mode(self) -> str:
        """Get simplified mode for C++ layer."""
        if self.is_write and not self.is_append:
            return "w"
        if self.is_append:
            return "a"
        return "r"

    @property
    def readable(self) -> bool:
        """Check if mode supports reading."""
        return self.is_read or self.is_update

    @property
    def writable(self) -> bool:
        """Check if mode supports writing."""
        return self.is_write or self.is_append or self.is_update


def parse_mode(mode: str) -> ParsedMode:
    """Parse a Python file mode string into components.

    Args:
        mode: Python file mode (e.g., 'rb', 'w+', 'rt', 'a')

    Returns:
        ParsedMode with parsed components

    Raises:
        ValueError: If mode is invalid

    Example:
        >>> parsed = parse_mode("r+b")
        >>> parsed.readable
        True
        >>> parsed.writable
        True
        >>> parsed.is_binary
        True
    """
    if not mode:
        raise ValueError("Mode cannot be empty")

    # Check for basic mode character
    has_read = "r" in mode
    has_write = "w" in mode
    has_append = "a" in mode
    has_update = "+" in mode
    has_binary = "b" in mode
    has_text = "t" in mode

    # Validate mode
    base_modes = sum([has_read, has_write, has_append])
    if base_modes == 0:
        raise ValueError(f"Invalid mode: {mode}. Must contain 'r', 'w', or 'a'")
    if base_modes > 1:
        raise ValueError(f"Invalid mode: {mode}. Cannot combine 'r', 'w', and 'a'")
    if has_binary and has_text:
        raise ValueError(f"Invalid mode: {mode}. Cannot have both 'b' and 't'")

    # Determine text/binary (default to text if not specified, matching Python's open())
    is_text = not has_binary
    is_binary = has_binary

    return ParsedMode(
        is_read=has_read,
        is_write=has_write,
        is_append=has_append,
        is_update=has_update,
        is_text=is_text,
        is_binary=is_binary,
    )


def normalize_mode_for_cpp(mode: str) -> str:
    """Convert Python file mode to C++ mode string.

    Args:
        mode: Python file mode (e.g., 'rb', 'w+b', 'at')

    Returns:
        Simplified mode for C++ layer ('r', 'w', or 'a')
    """
    return parse_mode(mode).cpp_mode


def is_text_mode(mode: str) -> bool:
    """Check if mode represents text mode.

    Text mode is when 'b' is NOT in the mode string.
    Bare modes ('r', 'w', 'a') default to text, matching Python's open().

    Args:
        mode: File mode string

    Returns:
        True if text mode, False for binary mode
    """
    return parse_mode(mode).is_text


def ensure_binary_mode(mode: str) -> str:
    """Ensure mode string is binary (for internal operations).

    Converts text mode indicators to binary equivalents.

    Args:
        mode: Original mode string

    Returns:
        Mode string with 'b' added if needed, 't' removed

    Example:
        >>> ensure_binary_mode("r")
        'rb'
        >>> ensure_binary_mode("wt")
        'wb'
        >>> ensure_binary_mode("rb")
        'rb'
    """
    # Remove 't' and ensure 'b' is present
    result = mode.replace("t", "")
    if "b" not in result:
        # Insert 'b' after the base mode character
        for base in ("r", "w", "a"):
            if base in result:
                idx = result.index(base) + 1
                result = result[:idx] + "b" + result[idx:]
                break
    return result


def get_buffered_wrapper_type(mode: str) -> str:
    """Determine the appropriate buffered wrapper type for a mode.

    Args:
        mode: File mode string

    Returns:
        One of 'reader', 'writer', or 'random'
    """
    parsed = parse_mode(mode)

    if parsed.is_update:
        return "random"
    if parsed.is_write or parsed.is_append:
        return "writer"
    return "reader"


# Lock type constants
LOCK_NONE = ""
LOCK_SHARED = "shared"
LOCK_EXCLUSIVE = "exclusive"

VALID_LOCK_TYPES = (LOCK_NONE, LOCK_SHARED, LOCK_EXCLUSIVE)


def validate_lock_type(lock_type: str) -> None:
    """Validate a lock type string.

    Args:
        lock_type: Lock type to validate

    Raises:
        ValueError: If lock type is invalid
    """
    if lock_type not in VALID_LOCK_TYPES:
        raise ValueError(
            f"Invalid lock_type: {lock_type}. Use '', 'shared', or 'exclusive'."
        )
