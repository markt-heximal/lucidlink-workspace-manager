"""
LucidLink Python Library - Type Definitions

Dataclasses and type definitions for LucidLink Python API.
Provides strongly-typed Python objects for filesystem entries and metadata.
"""

from dataclasses import dataclass


@dataclass
class DirEntry:
    """
    Represents a file or directory entry in the filesystem.

    Returned by Filesystem.read_dir() and Filesystem.get_entry().

    Attributes:
        name: Name of the file/directory (without path)
        size: Size in bytes (0 for directories)
        type: Entry type string ("file", "dir", "link", "unknown")
        file_id: Unique file identifier
        ctime: Creation time (Unix timestamp)
        mtime: Last modification time (Unix timestamp)
    """
    name: str
    size: int
    type: str
    file_id: str
    file_id_external: int
    ctime: int
    mtime: int

    def is_file(self) -> bool:
        """Check if this entry is a regular file."""
        return self.type == "file"

    def is_dir(self) -> bool:
        """Check if this entry is a directory."""
        return self.type == "dir"

    def is_link(self) -> bool:
        """Check if this entry is a symbolic link."""
        return self.type == "link"

    def __str__(self) -> str:
        return f"{self.type}: {self.name} ({self.size} bytes)"


@dataclass
class FilespaceInfo:
    """
    Summary information for a filespace in a workspace listing.

    Returned by Workspace.list_filespaces().

    Attributes:
        id: Unique filespace identifier
        name: Human-readable filespace name
        created: Creation timestamp (ISO 8601)
    """
    id: str
    name: str
    created: str


@dataclass
class DaemonStatus:
    """
    Daemon status information.

    Returned by Daemon.get_status().

    Attributes:
        is_running: Whether the daemon is currently running
        is_authenticated: Whether the daemon has authenticated to a workspace
        is_linked: Whether the daemon is linked to a filespace
        root_path: Root path for daemon operational files
    """
    is_running: bool
    is_authenticated: bool
    is_linked: bool
    root_path: str


@dataclass
class FilespaceSize:
    """
    Filespace size information.

    Returned by Filesystem.get_size().

    Attributes:
        entries: Size of metadata entries in bytes
        data: Size of file data in bytes
        storage: Total storage used in bytes
        external_files_size: Size of external (Connect) files in bytes
        external_files_count: Number of external (Connect) files
    """
    entries: int
    data: int
    storage: int
    external_files_size: int
    external_files_count: int

    def __str__(self) -> str:
        return (f"FilespaceSize(entries={self.entries}, "
                f"data={self.data}, "
                f"storage={self.storage})")


@dataclass
class FilespaceStatistics:
    """
    Filespace statistics.

    Returned by Filesystem.get_statistics().

    Attributes:
        file_count: Number of files in the filespace
        directory_count: Number of directories in the filespace
        symlink_count: Number of symbolic links in the filespace
        entries_size: Size of metadata entries in bytes
        data_size: Size of file data in bytes
        storage_size: Total storage used in bytes
        external_files_size: Size of external (Connect) files in bytes
        external_files_count: Number of external (Connect) files
    """
    file_count: int
    directory_count: int
    symlink_count: int
    entries_size: int
    data_size: int
    storage_size: int
    external_files_size: int
    external_files_count: int

    def __str__(self) -> str:
        return (f"FilespaceStatistics(files={self.file_count}, "
                f"directories={self.directory_count}, "
                f"symlinks={self.symlink_count})")
