"""
LucidLink Python Library

Python bindings for LucidLink Core C++ daemon library.
Provides programmatic access to LucidLink filespaces from Python.

Quick Start:
    import lucidlink

    # Using context manager (recommended)
    with lucidlink.Daemon() as daemon:
        workspace = daemon.authenticate(
            lucidlink.ServiceAccountCredentials(token="sa_live:key:secret")
        )
        filespace = workspace.link_filespace(name="myfilespace")

        # List files
        for entry in filespace.fs.read_dir("/"):
            print(f"{entry.name}: {entry.size} bytes")

        # Read/write files
        data = filespace.fs.read_file("/path/to/file.txt")
        filespace.fs.write_file("/output.txt", b"Hello World")

Manual lifecycle:
    daemon = lucidlink.Daemon()
    daemon.start()
    # ... use daemon ...
    daemon.stop()

Error handling:
    from lucidlink import AuthenticationError, FilespaceError

    try:
        workspace = daemon.authenticate(credentials)
    except AuthenticationError as e:
        print(f"Auth failed: {e}")

See README.md for full documentation.
"""

# Import main classes
from .credentials import ServiceAccountCredentials
from .daemon import Daemon
from .workspace import Workspace
from .filespace import Filespace
from .filesystem import Filesystem, FileHandle

# Import streaming classes
from .stream import LucidFileStream, open_buffered, open_text

# Import storage configuration
from .storage import StorageConfig, StorageMode

# Import Connect (external files) classes
from .connect import ConnectManager
from .connect_models import (
    S3DataStoreConfig,
    DataStoreInfo,
    LinkedFilesResult,
    DataStoreKind,
    DataStoreRekeyState,
    S3Credentials,
    DataStoreCredentials,
)

# Import fsspec integration (optional - requires fsspec package)
try:
    from .fsspec import LucidLinkFileSystem, SyncMode
    _FSSPEC_AVAILABLE = True
except ImportError:
    _FSSPEC_AVAILABLE = False
    LucidLinkFileSystem = None
    SyncMode = None

# Import custom exceptions
from .exceptions import (
    LucidLinkError,
    DaemonError,
    FilespaceError,
    AuthenticationError,
    ConfigurationError,
)

# Import type definitions
from .models import (
    DirEntry,
    FilespaceInfo,
    DaemonStatus,
    FilespaceSize,
    FilespaceStatistics,
)

# Import typing for factory function
from typing import Dict, Optional, Union
from pathlib import Path

__version__ = "0.6.0"
__all__ = [
    # Main classes
    "ServiceAccountCredentials",
    "Daemon",
    "Workspace",
    "Filespace",
    "Filesystem",
    "FileHandle",
    # Streaming classes
    "LucidFileStream",
    "open_buffered",
    "open_text",
    # Storage configuration
    "StorageConfig",
    "StorageMode",
    # Connect (external files)
    "ConnectManager",
    "S3DataStoreConfig",
    "DataStoreInfo",
    "LinkedFilesResult",
    "DataStoreKind",
    "DataStoreRekeyState",
    "S3Credentials",
    "DataStoreCredentials",
    # fsspec integration
    "LucidLinkFileSystem",
    "SyncMode",
    # Exceptions
    "LucidLinkError",
    "DaemonError",
    "FilespaceError",
    "AuthenticationError",
    "ConfigurationError",
    # Types
    "DirEntry",
    "FilespaceInfo",
    "DaemonStatus",
    "FilespaceSize",
    "FilespaceStatistics",
    # Factory functions
    "create_daemon",
]


def create_daemon(
    config: Optional[Dict[str, str]] = None,
    sandboxed: bool = True,
    persist_files: bool = False,
    root_path: Optional[Union[str, Path]] = None,
) -> Daemon:
    """
    Create a Daemon with simplified storage configuration.

    This is a convenience factory that makes it easier to configure daemon
    storage without needing to manually create StorageConfig objects.

    Args:
        config: Additional daemon configuration options (cache size, etc.)
        sandboxed: If True (default), use temp directory that's always cleaned up.
                  If False, use .lucid subfolder in current directory.
        persist_files: If False (default), clean up files when daemon stops.
                      Only applies when sandboxed=False.
                      Sandboxed mode always cleans up.
        root_path: Override root path for files (only when sandboxed=False).
                  If None, uses current working directory.

    Returns:
        Daemon instance with specified storage configuration

    Examples:
        # Sandboxed (default) - files in temp, always cleaned up
        >>> daemon = lucidlink.create_daemon()

        # Physical with cleanup - files in .lucid/, cleaned up on exit
        >>> daemon = lucidlink.create_daemon(sandboxed=False)

        # Physical with persistence - files in .lucid/, kept after exit
        >>> daemon = lucidlink.create_daemon(sandboxed=False, persist_files=True)

        # Custom root path
        >>> daemon = lucidlink.create_daemon(
        ...     sandboxed=False,
        ...     root_path="D:/lucid_data"
        ... )

        # With custom config
        >>> daemon = lucidlink.create_daemon(
        ...     config={"fs.cache.size": "2048"},
        ...     sandboxed=False,
        ...     persist_files=True
        ... )
    """
    if sandboxed:
        storage = StorageConfig(mode=StorageMode.SANDBOXED)
    else:
        storage = StorageConfig(
            mode=StorageMode.PHYSICAL,
            persist_on_exit=persist_files,
            root_path=Path(root_path) if root_path else None,
        )
    return Daemon(config=config, storage=storage)
