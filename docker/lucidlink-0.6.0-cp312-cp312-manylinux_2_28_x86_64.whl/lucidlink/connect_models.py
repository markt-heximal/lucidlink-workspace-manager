"""Data models for LucidLink Connect (external files)."""

import enum
from dataclasses import dataclass, field
from typing import List


class DataStoreKind(str, enum.Enum):
    S3 = "S3DataStore"


class DataStoreRekeyState(str, enum.Enum):
    NO_REKEY = "no_rekey"
    IN_PROGRESS = "in_progress"


@dataclass
class S3Credentials:
    access_key: str
    secret_key: str
    kind: DataStoreKind = DataStoreKind.S3


DataStoreCredentials = S3Credentials


@dataclass
class S3DataStoreConfig:
    """Configuration for an S3-compatible data store.

    Args:
        access_key: S3 access key ID
        secret_key: S3 secret access key
        bucket_name: S3 bucket name
        region: AWS region (e.g., "us-east-1")
        endpoint: Custom S3 endpoint URL with scheme, e.g. "http://127.0.0.1:9090".
            Must start with "http://" or "https://". When empty, defaults to HTTPS.
        url_expiration_minutes: Presigned URL expiration in minutes (default: 10080 = 7 days)
        use_virtual_addressing: Use virtual-hosted-style addressing (default: False)
    """
    access_key: str
    secret_key: str
    bucket_name: str
    region: str
    endpoint: str = ""
    url_expiration_minutes: int = 10080  # 7 days
    use_virtual_addressing: bool = False


@dataclass
class DataStoreInfo:
    """Information about a registered data store.

    Attributes:
        name: Data store name
        access_key: S3 access key ID
        secret_key: S3 secret access key
        bucket_name: S3 bucket name
        region: AWS region
        endpoint: Full S3 endpoint URL (e.g., "http://127.0.0.1:9090"), empty if using AWS default
        url_expiration_minutes: Presigned URL expiration in minutes
        use_virtual_addressing: Whether virtual-hosted-style addressing is used
        kind: Data store type (currently always S3)
        key_id: Unique key identifier (UUID)
        rekey_state: Current credential rotation state
    """
    name: str
    access_key: str = ""
    secret_key: str = ""
    bucket_name: str = ""
    region: str = ""
    endpoint: str = ""
    url_expiration_minutes: int = 0
    use_virtual_addressing: bool = False
    kind: DataStoreKind = DataStoreKind.S3
    key_id: str = ""
    rekey_state: DataStoreRekeyState = DataStoreRekeyState.NO_REKEY

    @classmethod
    def from_dict(cls, store: dict) -> "DataStoreInfo":
        return cls(
            **{
                **store,
                "kind": DataStoreKind(store.get("kind", "S3DataStore")),
                "rekey_state": DataStoreRekeyState(store.get("rekey_state", "no_rekey")),
            }
        )


@dataclass
class LinkedFilesResult:
    """Result from listing external files linked to a data store.

    Attributes:
        file_paths: List of file paths
        file_ids: List of integer file IDs (parallel to file_paths)
        has_more: Whether more results are available (pagination)
        cursor: Opaque pagination token; pass to the next call to continue
    """
    file_paths: List[str] = field(default_factory=list)
    file_ids: List[int] = field(default_factory=list)
    has_more: bool = False
    cursor: str = ""
